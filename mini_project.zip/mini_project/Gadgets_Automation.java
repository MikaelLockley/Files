package mini_project;

//import java.time.Duration;
//import java.util.List;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;

/*public class Gadgets_Automation {

	public static void main(String[] args) {
			
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\2389317\\eclipse-workspace\\tekstac_HandSons\\Driver\\chromedriver.exe");
		 	WebDriver driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("https://www.snapdeal.com/");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	        
	        //Searching for Bluetooth headphone
	        WebElement searchBoxElement = driver.findElement(By.id("inputValEnter"));
	        searchBoxElement.sendKeys("Bluetooth headphone");
	        
	        WebElement searchButtonElement = driver.findElement(By.xpath("//button[@class ='searchformButton col-xs-4 rippleGrey']"));
	        searchButtonElement.click();
	        
//	        WebElement sortElement = driver.findElement(By.xpath("//div[@class='sort-selected']"));
//	        sortElement.sendKeys("Popularity");
	        
	        //Setting price ranges
	        WebElement fromValElement =  driver.findElement(By.xpath("//input[@name='fromVal']"));
	        fromValElement.clear();
	        fromValElement.sendKeys("700");
	        WebElement toValElement = driver.findElement(By.xpath("//input[@name='toVal']"));
	        toValElement.clear();
	        toValElement.sendKeys("1400");
	        
	        driver.findElement(By.xpath("//div[@class='price-go-arrow btn btn-line btn-theme-secondary']")).click();
	       wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='products']")));
	        //getting products 
	        List<WebElement> productsElements = driver.findElements(By.xpath("//*[@id='products']"));
	        
	        for(WebElement webElement : productsElements) {
	        	System.out.println(webElement.getText());
	        }

	}

}

*/
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;

public class Gadgets_Automation {

    public static void main(String[] args) {
        // 1. Set up the Chrome Driver
        //System.setProperty("webdriver.chrome.driver", "path/to/chromedriver.exe"); // Replace with the actual path

        // Configure Chrome options for headless mode (optional, for running without UI)
        ChromeOptions options = new ChromeOptions();
        //options.addArguments("--headless=new"); // Add this for headless mode

        // 2. Initialize the WebDriver
        WebDriver driver = new ChromeDriver(options);
        // Maximize the browser window
        driver.manage().window().maximize();

        // 3. Navigate to Snapdeal
        driver.get("https://www.snapdeal.com/");

        try {
            // 4. Search for "Bluetooth headphone"
            WebElement searchInput = driver.findElement(By.id("inputValEnter"));
            searchInput.sendKeys("Bluetooth headphone");
            searchInput.sendKeys(Keys.ENTER);

            // 5. Wait for the search results to load (important for dynamic websites)
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Increased timeout to 10 seconds
            wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".sort-drop")));

            // 6. Sort by "Popularity"
            WebElement sortByDropdown = driver.findElement(By.cssSelector(".sort-drop")); // Changed selector
            sortByDropdown.click();
            //wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[contains(text(),'Popularity')]")));
            WebElement popularityOption = driver.findElement(By.xpath("//*[@id=\"content_wrapper\"]/div[7]/div[5]/div[3]/div[1]/div/div[2]/ul/li[2]"));
            popularityOption.click();

            // 7. Apply the price range filter
            WebElement minPriceInput = driver.findElement(By.name("fromVal"));
            minPriceInput.clear();
            minPriceInput.sendKeys("700");

            WebElement maxPriceInput = driver.findElement(By.name("toVal"));
            maxPriceInput.clear();
            maxPriceInput.sendKeys("1400");

            WebElement goButton = driver.findElement(By.xpath("//div[@class='price-go-arrow btn btn-line btn-theme-secondary']")); // Corrected selector.
            goButton.click();

            // Wait for the filter to apply
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"products\"]")));
            // 8. Get the first 5 headphone names and prices
            List<WebElement> productNames = driver.findElements(By.xpath("//p[@class = 'product-title']"));
            List<WebElement> productPrices = driver.findElements(By.xpath("//span[@class = 'lfloat product-price']"));
//          wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//p[contains(@class, 'product-title')]")));
//          wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='products']")));
          
//         Thread.sleep(3000);
            System.out.println("First 5 Bluetooth Headphones (700-1400 Price Range):");
            int count = Math.min(5, Math.min(productNames.size(), productPrices.size())); // Ensure we don't go out of bounds
            for (int i = 0; i < count; i++) {
                String name = productNames.get(i).getText();
                String priceText = productPrices.get(i).getText();
                // Extract only the numeric value from the price string
                String price = priceText.replaceAll("[^0-9]", "");
                System.out.println((i + 1) + ". " + name + " - Price: ₹" + price);
            }

        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
        } finally {
            // 9. Close the browser
            driver.quit();
        }
    }
}

