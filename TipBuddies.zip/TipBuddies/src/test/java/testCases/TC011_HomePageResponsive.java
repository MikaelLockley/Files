package testCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pageObjects.HomePage;
import testBase.BaseClass;

public class TC011_HomePageResponsive extends BaseClass{

	
	@Test(priority = 1)
    public void verifyLogoHeadingNoCollisionAcrossDevices() {
        HomePage homePage = new HomePage(driver);
        SoftAssert softAssert = new SoftAssert(); // Create an instance of SoftAssert
        java.util.Map<String, Integer> viewports = new java.util.HashMap<>();
        viewports.put("Desktop", 1200);
        viewports.put("Tablet", 768);
        viewports.put("Mobile", 375); // Including mobile to ensure no collision there either

        for (java.util.Map.Entry<String, Integer> entry : viewports.entrySet()) {
            String device = entry.getKey();
            int width = entry.getValue();
            driver.manage().window().setSize(new org.openqa.selenium.Dimension(width, 800)); // Adjust height as needed

            System.out.println("Checking logo collision with heading on " + device + " (width: " + width + "px)");

            WebElement logo = homePage.logo;
            WebElement heading = driver.findElement(By.tagName("h1")); // Assuming h1 is the heading - ADJUST IF NEEDED

            org.openqa.selenium.Rectangle logoRect = logo.getRect();
            org.openqa.selenium.Rectangle headingRect = heading.getRect();

            // Check for intersection by comparing coordinates
            boolean logoOverlapsHeading = !(logoRect.getX() + logoRect.getWidth() < headingRect.getX() ||
                                             logoRect.getX() > headingRect.getX() + headingRect.getWidth() ||
                                             logoRect.getY() + logoRect.getHeight() < headingRect.getY() ||
                                             logoRect.getY() > headingRect.getY() + headingRect.getHeight());

            softAssert.assertFalse(logoOverlapsHeading, "Logo and heading should not collide on " + device + " view.");
            System.out.println("Collision check on " + device + " view completed. Collision: " + logoOverlapsHeading);
        }
        // Reset the browser size to default (optional)
        driver.manage().window().maximize();

        softAssert.assertAll(); // This line must be called at the end to report all failures
    }
}
