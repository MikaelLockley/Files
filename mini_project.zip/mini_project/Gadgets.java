package mini_project;
 
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
 
public class Gadgets {
     private static final String EXCEL_FILE_PATH = "C:\\Users\\2389317\\eclipse-workspace\\tekstac_HandSons\\product_data.xlsx";
 
     public static void main(String[] args) throws IOException {
         // Load input data from the first line of the Excel sheet
         FileInputStream fis = new FileInputStream(EXCEL_FILE_PATH);
         Workbook workbook = new XSSFWorkbook(fis);
         Sheet sheet = workbook.getSheetAt(0); //Input data is in the first sheet
         Row inputRow = sheet.getRow(0);
 
         if (inputRow == null || inputRow.getLastCellNum() < 4) {
             System.out.println("Error: First row in Excel must contain website URL, search keyword, min price, and max price.");
             workbook.close();
             fis.close();
             return;
         }
 
         String websiteUrl = inputRow.getCell(0).getStringCellValue();
         String searchKeyword = inputRow.getCell(1).getStringCellValue();
         int minPrice = (int) inputRow.getCell(2).getNumericCellValue();
         int maxPrice = (int) inputRow.getCell(3).getNumericCellValue();
 
         System.out.println("Inputs from Excel:");
         System.out.println("Website URL: " + websiteUrl);
         System.out.println("Search Keyword: " + searchKeyword);
         System.out.println("Minimum Price: " + minPrice);
         System.out.println("Maximum Price: " + maxPrice);
         System.out.println("--------------------");
 
         // Initialize WebDriver
         WebDriver driver = new ChromeDriver();
         driver.manage().window().maximize();
         driver.get(websiteUrl);
 
         // Searching for the product
//         System.setProperty("webdriver.chrome.driver", "C:\\Users\\2389317\\eclipse-workspace\\tekstac_HandSons\\Driver\\chromedriver.exe");
        // we can directly run this Without assigning 
         WebElement searchBoxElement = driver.findElement(By.id("inputValEnter"));
         searchBoxElement.sendKeys(searchKeyword);
         driver.findElement(By.xpath("//button[@class=\"searchformButton col-xs-4 rippleGrey\"]")).click();
 
         // Sort the search
         WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='sort-drop clearfix']"))).click();
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@class='sort-value']/li[2]"))).click();
 
         // Setting price range
         WebElement fromValElement = driver.findElement(By.name("fromVal"));
         fromValElement.clear();
         fromValElement.sendKeys(String.valueOf(minPrice));
         WebElement toValElement = driver.findElement(By.name("toVal"));
         toValElement.clear();
         toValElement.sendKeys(String.valueOf(maxPrice));
         driver.findElement(By.xpath("//div[@class= 'price-go-arrow btn btn-line btn-theme-secondary']")).click();
 
         wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//p[contains(@class, 'product-title')]")));
 
         List<String> productNames = new ArrayList<>();
         List<String> productPricesList = new ArrayList<>();
 
         for (int i = 0; i < 5; i++) {
             try {
                 // Re-fetch product elements in every iteration to get the latest items
                 List<WebElement> productTitles = driver.findElements(By.xpath("//p[contains(@class, 'product-title')]"));
                 List<WebElement> productPrices = driver.findElements(By.xpath("//span[@class='lfloat product-price']"));
 
                 String productName = productTitles.get(i).getText();
                 String priceText = productPrices.get(i).getText().replaceAll("[^0-9]", ""); // Extract only numbers
 
                 if (!priceText.isEmpty()) {
                     int price = Integer.parseInt(priceText);
                     if (price >= minPrice && price <= maxPrice) {
                         productNames.add(productName);
                         productPricesList.add(productPrices.get(i).getText());
                         System.out.println("Product " + (i + 1) + ": " + productName + " - " + productPrices.get(i).getText());
                     } else {
                         i--; // Retry the current iteration if price is out of range
                     }
                 }
 
             } catch (StaleElementReferenceException e) {
                 i--; // Retry the current iteration if element becomes stale
             }
         }
 
         boolean writeSuccessful = false;
 
         // Write the extracted product data to the Excel sheet
         // Open the existing workbook
         try (FileInputStream existingFile = new FileInputStream(EXCEL_FILE_PATH);
              Workbook existingWorkbook = new XSSFWorkbook(existingFile)) {
 
             Sheet dataSheet = existingWorkbook.getSheet("Product Data");
             if (dataSheet == null) {
                 dataSheet = existingWorkbook.createSheet("Product Data");
             }
 
             // Clear existing product data from the 3rd line onwards
             for (int i = dataSheet.getLastRowNum(); i >= 2; i--) {
                 Row rowToDelete = dataSheet.getRow(i);
                 if (rowToDelete != null) {
                     dataSheet.removeRow(rowToDelete);
                 }
             }
 
          // Create header row starting from the 3rd line (index 2)
             Row headerRow = dataSheet.createRow(2);
             Cell cellProductNameHeader = headerRow.createCell(0);
             Cell cellPriceHeader = headerRow.createCell(1);
             cellProductNameHeader.setCellValue("Product Name");
             cellPriceHeader.setCellValue("Price");
 
 
             // Write product data to Excel starting from the 4th line (index 3)
             for (int i = 0; i < productNames.size(); i++) {
                 Row dataRow = dataSheet.createRow(i + 3);
                 dataRow.createCell(0).setCellValue(productNames.get(i));
                 dataRow.createCell(1).setCellValue(productPricesList.get(i));
             }
 
             // Write to Excel file
             try (FileOutputStream outputStream = new FileOutputStream(EXCEL_FILE_PATH)) {
                 existingWorkbook.write(outputStream);
                 writeSuccessful = true; // Set flag to true if writing is successful
             } catch (IOException e) {
                 System.err.println("Error writing to Excel file: " + e.getMessage());
             }
 
         } finally {
             workbook.close();
             fis.close();
             driver.quit(); // Keep this commented out if you want to inspect the browser
         }
         System.out.println("--------------------");
         if (writeSuccessful) {
             System.out.println("\nSuccessfully entered product data into the Excel sheet.");
         }
     }
}